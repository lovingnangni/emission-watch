# Emission Watch — iPad-friendly upload

아이패드에서 GitHub에 올리기 쉽게 **모든 필수 파일 8개를 한 폴더에** 배치했습니다.

1. ZIP을 파일 앱에 저장하고 탭하여 압축을 풉니다.
2. `emission_watch_ipad_upload` 폴더 안의 **파일 8개**를 GitHub 저장소의 최상위(root)에 업로드합니다. 폴더 자체나 ZIP 파일을 올리면 앱이 실행되지 않습니다.
3. `app.py`, `core.py`, `requirements.txt`, `metadata.json`, `reference_2013.csv`, `demo_2014.csv`, `nox_model.joblib`, `README.md`가 저장소 첫 화면에 보이는지 확인합니다.
4. Streamlit Community Cloud에서 해당 GitHub 저장소를 연결한 다음 Main file path에 `app.py`를 입력합니다.

본 앱은 2011–2012년 학습, 2013년 검증, 2014년 탐색용 가스터빈 NOx 분석 프로토타입입니다. 실제 설비 고장·배출 규정 위반을 판단하지 않습니다.

데이터 출처: [UCI Gas Turbine CO and NOx Emission Data Set](https://archive.ics.uci.edu/dataset/551/gas+turbine+co+and+nox+emission+data+set), CC BY 4.0.
