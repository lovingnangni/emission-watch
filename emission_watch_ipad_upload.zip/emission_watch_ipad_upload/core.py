"""Deterministic analysis helpers for Emission Watch (no Streamlit dependency).

The bundled model is a joblib file produced by the project author. Only load
this trusted, bundled artifact; never load arbitrary user-uploaded pickle files.
"""
from __future__ import annotations

import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

DATA_DIR = Path(__file__).resolve().parent


def load_artifacts(data_dir: Path = DATA_DIR):
    data_dir = Path(data_dir)
    with (data_dir / "metadata.json").open(encoding="utf-8") as handle:
        meta = json.load(handle)
    reference = pd.read_csv(data_dir / "reference_2013.csv")
    demo = pd.read_csv(data_dir / "demo_2014.csv")
    # joblib loads Python objects. This file is a trusted, bundled artifact.
    model = joblib.load(data_dir / "nox_model.joblib")
    required = set(meta["features"] + ["record_id", "NOX"])
    for label, frame in (("reference_2013.csv", reference), ("demo_2014.csv", demo)):
        missing = required.difference(frame.columns)
        if missing:
            raise ValueError(f"{label}: missing columns {sorted(missing)}")
        if frame.record_id.duplicated().any():
            raise ValueError(f"{label}: duplicate record_id")
    return meta, reference, demo, model


def prepare_analysis(meta, reference, demo, model):
    """Rebuild nearest neighbors and check included predictions match model."""
    features = meta["features"]
    demo = demo.copy()
    reference = reference.copy()
    actual_prediction = model.predict(demo[features])
    if not np.allclose(actual_prediction, demo["predicted_NOX"], atol=1e-6, rtol=1e-7):
        raise ValueError("Bundled model and stored 2014 predictions do not match")
    if not np.allclose(demo["NOX"] - demo["predicted_NOX"], demo["residual"], atol=1e-6):
        raise ValueError("Stored residuals do not match measured - predicted")

    scaler = StandardScaler().fit(reference[features])
    neighbors = NearestNeighbors(n_neighbors=1).fit(scaler.transform(reference[features]))
    distances, indices = neighbors.kneighbors(scaler.transform(demo[features]))
    demo["nearest_id"] = reference.iloc[indices[:, 0]]["record_id"].to_numpy()
    demo["nearest_NOX"] = reference.iloc[indices[:, 0]]["NOX"].to_numpy()
    demo["nearest_distance"] = distances[:, 0]
    threshold = float(meta["matching_distance_threshold"])
    demo["has_comparison"] = demo["nearest_distance"] <= threshold
    if not np.allclose(demo["nearest_distance"], demo["match_distance"], atol=1e-6):
        raise ValueError("Stored and recalculated neighbor distances differ")
    match_rows = demo["has_comparison"]
    if not np.allclose(demo.loc[match_rows, "nearest_NOX"], demo.loc[match_rows, "matched_NOX"], atol=1e-6):
        raise ValueError("Stored and recalculated matched NOX values differ")
    if not np.array_equal(match_rows.to_numpy(), (demo["comparison_status"] == "유사 기록 있음").to_numpy()):
        raise ValueError("Stored and recalculated comparison decisions differ")

    valid_preds = model.predict(reference[features])
    valid_metrics = {
        "mae": float(mean_absolute_error(reference["NOX"], valid_preds)),
        "r2": float(r2_score(reference["NOX"], valid_preds)),
        "bias": float(np.mean(reference["NOX"].to_numpy() - valid_preds)),
    }
    current_metrics = {
        "mae": float(mean_absolute_error(demo["NOX"], demo["predicted_NOX"])),
        "r2": float(r2_score(demo["NOX"], demo["predicted_NOX"])),
        "bias": float(demo["residual"].mean()),
    }
    if not np.isclose(valid_metrics["mae"], float(meta["validation_mae"]), atol=1e-6):
        raise ValueError("Reference validation MAE is inconsistent with metadata")
    return demo, reference, valid_metrics, current_metrics


def evidence_report(row: pd.Series, reference: pd.DataFrame, valid_metrics: dict, current_metrics: dict, threshold: float):
    record_id = int(row["record_id"])
    residual = float(row["residual"])
    lines = [
        f"Emission Watch | 2014년 기록 #{record_id}",
        "[확인된 측정·계산 결과]",
        f"실제 NOₓ: {float(row['NOX']):.3f} mg/m³",
        f"모델 예측 NOₓ: {float(row['predicted_NOX']):.3f} mg/m³",
        f"예측오차(실제 − 예측): {residual:+.3f} mg/m³",
        "[모델 상태 - 연도별 집계]",
        f"2013 MAE {valid_metrics['mae']:.3f} / 2014 MAE {current_metrics['mae']:.3f}",
        f"2013 평균 오차 {valid_metrics['bias']:+.3f} / 2014 평균 오차 {current_metrics['bias']:+.3f}",
    ]
    if bool(row["has_comparison"]):
        neighbor = reference.set_index("record_id").loc[int(row["nearest_id"])]
        lines += [
            "[유사 운전 기록 - 탐색적 비교]",
            f"2013년 기록 #{int(row['nearest_id'])}, NOₓ {float(neighbor['NOX']):.3f} mg/m³",
            f"2014년 측정값과 유사 기록의 차이: {float(row['NOX'] - neighbor['NOX']):+.3f} mg/m³",
            f"표준화 거리 {float(row['nearest_distance']):.3f} (임시 기준 ≤ {threshold:.3f})",
        ]
    else:
        lines += [
            "[유사 운전 기록]",
            f"임시 거리 기준(≤ {threshold:.3f})을 통과하는 과거 기록이 없어 비교를 보류합니다.",
        ]
    lines += [
        "[해석의 한계]",
        "2014년에는 모델의 연도별 성능과 평균 오차가 달라졌습니다. ",
        "개별 예측오차나 유사 기록 간 차이만으로 고장, 배출규제 위반, 이상 원인을 판정할 수 없습니다.",
        "출처: UCI Gas Turbine CO and NOx Emission Data Set (2011–2015), CC BY 4.0.",
    ]
    return "\n".join(lines)
