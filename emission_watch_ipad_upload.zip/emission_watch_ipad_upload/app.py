"""Emission Watch: a transparent research prototype for gas-turbine NOx analysis."""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from core import DATA_DIR, evidence_report, load_artifacts, prepare_analysis

st.set_page_config(
    page_title="Emission Watch | Nangni Insight",
    page_icon="🌿",
    layout="wide",
    initial_sidebar_state="expanded",
)


@st.cache_resource(show_spinner="모델과 실제 분석 데이터를 불러오는 중입니다…")
def get_data():
    meta, reference, demo, model = load_artifacts(DATA_DIR)
    analyzed, reference, validation, current = prepare_analysis(meta, reference, demo, model)
    return meta, reference, analyzed, validation, current


try:
    meta, reference, demo, validation, current = get_data()
except Exception as exc:
    st.error("분석 파일을 불러오지 못했습니다. 업로드한 모델·CSV·metadata.json 파일 및 패키지 버전을 확인해 주세요.")
    st.exception(exc)
    st.stop()

threshold = float(meta["matching_distance_threshold"])
feature_names = meta["features"]
matched_count = int(demo["has_comparison"].sum())
matched_ratio = matched_count / len(demo)

st.title("🌿 Emission Watch")
st.caption("Nangni Insight의 첫 번째 모듈 · 실제 가스터빈 데이터 기반 NOₓ 패턴 조사 프로토타입")
st.warning(
    "**모델 상태 점검 필요:** 2014년에는 2013년보다 예측오차가 커지고 평균 오차 방향도 바뀌었습니다. "
    "개별 예측오차를 설비 고장·법규 위반·원인으로 판정하지 않습니다."
)

with st.sidebar:
    st.header("데이터와 모델")
    st.write("**훈련:** 2011–2012년")
    st.write("**검증:** 2013년")
    st.write("**탐색·시연:** 2014년")
    st.write("**2015년:** 사용하지 않음 (최종 평가용 보류)")
    st.divider()
    st.caption("실시간 연결이 아닌 공개 데이터 분석 시연입니다. 모든 기록 ID는 날짜나 시각이 아닙니다.")
    st.markdown("[원본 공개 데이터 보기](https://archive.ics.uci.edu/dataset/551/gas+turbine+co+and+nox+emission+data+set)")

overview, investigation, methodology = st.tabs(["📊 전체 현황", "🔎 기록 조사", "📚 방법·한계"])

with overview:
    a, b, c, d = st.columns(4)
    a.metric("2014년 분석 기록", f"{len(demo):,}건")
    b.metric("2013년 검증 MAE", f"{validation['mae']:.3f}")
    c.metric("2014년 탐색 MAE", f"{current['mae']:.3f}")
    d.metric("유사 기록 기준 통과", f"{matched_ratio:.1%}")
    st.caption(
        "유사 기록 기준 통과율은 임시 표준화 거리 기준에서 얻은 값이며, "
        "모델 신뢰도나 이상 발생률을 의미하지 않습니다."
    )

    st.subheader("모델 상태: 같은 모델의 연도별 성능")
    metrics = pd.DataFrame(
        [
            {"평가 연도": "2013 · 검증", "MAE": validation["mae"],
             "R²": validation["r2"], "평균 오차(실제−예측)": validation["bias"]},
            {"평가 연도": "2014 · 탐색", "MAE": current["mae"],
             "R²": current["r2"], "평균 오차(실제−예측)": current["bias"]},
        ]
    )
    st.dataframe(metrics.style.format({"MAE": "{:.3f}", "R²": "{:.3f}", "평균 오차(실제−예측)": "{:+.3f}"}),
                 hide_index=True, use_container_width=True)
    st.info(
        "**읽는 법:** 2014년의 평균 오차가 음수인 것은 모델이 실제 NOₓ를 전반적으로 높게 예측했다는 뜻입니다. "
        "원인이나 설비 상태의 변화는 이 자료만으로 확인할 수 없습니다."
    )

    st.subheader("2014년 실제값과 AI 예측값")
    sample = demo.sample(n=min(2200, len(demo)), random_state=42)
    figure = go.Figure()
    figure.add_trace(go.Scattergl(
        x=sample["NOX"], y=sample["predicted_NOX"], mode="markers",
        marker={"size": 5, "opacity": 0.28, "color": "#55c7cb"},
        text=sample["record_id"].map(lambda x: f"기록 #{int(x)}"),
        hovertemplate="%{text}<br>실제 NOₓ %{x:.2f}<br>예측 NOₓ %{y:.2f}<extra></extra>",
        name="2014년 기록 일부",
    ))
    low = float(min(sample["NOX"].min(), sample["predicted_NOX"].min()))
    high = float(max(sample["NOX"].max(), sample["predicted_NOX"].max()))
    figure.add_trace(go.Scatter(
        x=[low, high], y=[low, high], mode="lines",
        line={"color": "#e5edf0", "dash": "dash"}, name="실제 = 예측"
    ))
    figure.update_layout(
        xaxis_title="실제 NOₓ (mg/m³)", yaxis_title="모델 예측 NOₓ (mg/m³)",
        legend={"orientation": "h"}, height=450, margin={"t": 20, "b": 20},
    )
    st.plotly_chart(figure, use_container_width=True)
    st.caption("표시 속도를 위해 2014년 기록 중 최대 2,200건을 재현 가능한 방식으로 추출했습니다. 지표는 전체 7,158건으로 계산했습니다.")

    st.subheader("유사 운전 기록을 찾을 수 있었을까?")
    x, y = st.columns(2)
    with x:
        st.metric("임시 거리 기준 통과", f"{matched_count:,} / {len(demo):,}건")
        st.write("2013년의 9개 운전 변수를 비교해 가장 가까운 기록을 검색했습니다.")
    with y:
        st.metric("비교 보류", f"{len(demo) - matched_count:,}건")
        st.write("충분히 가까운 기록이 없는 경우, 과거 NOₓ 차이를 근거처럼 제시하지 않습니다.")
    st.caption("기준: 2013년 기록이 자기 자신을 제외한 가장 가까운 2013년 기록까지의 거리 중 95백분위수. 탐색용 기준입니다.")

with investigation:
    st.subheader("기록 하나를 선택해 근거 확인하기")
    st.caption("ID를 입력해 검색할 수 있습니다. 입력값은 UCI 데이터의 원본 행 인덱스이며 시각 정보는 없습니다.")
    top_pos = int(demo.loc[demo["residual"].idxmax(), "record_id"])
    top_neg = int(demo.loc[demo["residual"].idxmin(), "record_id"])
    matched_id = int(demo.loc[demo["has_comparison"], "record_id"].iloc[0])
    unmatched_id = int(demo.loc[~demo["has_comparison"], "record_id"].iloc[0])
    examples = {
        "유사 운전 기록 있음": matched_id,
        "비교 자료 부족": unmatched_id,
        "실제값이 예측보다 가장 큰 사례": top_pos,
        "실제값이 예측보다 가장 작은 사례": top_neg,
    }
    col_choice, col_id = st.columns([1, 1])
    with col_choice:
        example = st.selectbox("빠른 예제 선택", list(examples), index=0)
    with col_id:
        selected_id = st.selectbox(
            "기록 ID (번호를 입력해 검색 가능)",
            options=demo["record_id"].astype(int).tolist(),
            index=demo.index.get_loc(demo.index[demo["record_id"] == examples[example]][0]),
            key=f"record_{example}",
        )
    row = demo.loc[demo["record_id"] == selected_id].iloc[0]
    st.caption(f"2014년 기록 #{int(row['record_id'])} · 아래 수치는 저장된 실제 분석 결과입니다.")
    a, b, c = st.columns(3)
    a.metric("실제 NOₓ", f"{row['NOX']:.3f} mg/m³")
    b.metric("예측 NOₓ", f"{row['predicted_NOX']:.3f} mg/m³")
    c.metric("예측오차 (실제−예측)", f"{row['residual']:+.3f} mg/m³")
    st.warning("이 기록의 오차만으로 실제 고장이나 배출 이상 여부를 판정할 수 없습니다. 2014년 모델 전체에 편향이 관찰됩니다.")

    st.subheader("Condition Twin · 유사 운전 조건 비교")
    if bool(row["has_comparison"]):
        neighbor = reference.set_index("record_id").loc[int(row["nearest_id"])]
        st.success(
            f"임시 거리 기준 통과 · 2013년 기록 #{int(row['nearest_id'])} "
            f"(거리 {row['nearest_distance']:.3f} / 기준 {threshold:.3f})"
        )
        st.metric("과거 유사 기록의 실제 NOₓ", f"{neighbor['NOX']:.3f} mg/m³")
        st.write(f"두 기록의 NOₓ 측정값 차이: **{row['NOX'] - neighbor['NOX']:+.3f} mg/m³**")
        st.caption("통계적으로 가까운 운전 기록일 뿐, 모든 운전 조건이나 측정 환경이 같음을 보장하지 않습니다.")
        comparison = pd.DataFrame({
            "운전 변수": feature_names,
            "2014년 선택 기록": [float(row[f]) for f in feature_names],
            "2013년 유사 기록": [float(neighbor[f]) for f in feature_names],
        })
        comparison["차이 (2014−2013)"] = comparison["2014년 선택 기록"] - comparison["2013년 유사 기록"]
        st.dataframe(comparison.style.format({
            "2014년 선택 기록": "{:.3f}", "2013년 유사 기록": "{:.3f}", "차이 (2014−2013)": "{:+.3f}",
        }), hide_index=True, use_container_width=True)
    else:
        st.warning(
            f"**비교 보류:** 가장 가까운 과거 기록과의 거리가 {row['nearest_distance']:.3f}로 "
            f"임시 기준 {threshold:.3f}을 넘습니다. 과거 NOₓ를 비교 근거로 제시하지 않습니다."
        )
        st.caption("비교 보류는 공정 이상이나 모델 오류가 확인됐다는 뜻이 아닙니다.")

    st.subheader("Evidence Card · 확인 가능한 것과 모르는 것")
    report = evidence_report(row, reference, validation, current, threshold)
    st.code(report, language=None)
    st.download_button(
        "이 기록의 근거 카드 다운로드 (.txt)",
        data=report.encode("utf-8-sig"),
        file_name=f"emission_watch_{int(row['record_id'])}.txt",
        mime="text/plain",
    )

with methodology:
    st.subheader("분석 방법")
    st.markdown(
        """
- **원본:** UCI *Gas Turbine CO and NOx Emission Data Set*, 2011–2015년 측정 기록 (CC BY 4.0).
- **모델:** 2011–2012년 기록의 9개 운전 변수를 입력으로 쓰는 `HistGradientBoostingRegressor`; `NOX`를 예측. `CO`와 `year`는 입력에서 제외.
- **검증:** 2013년 데이터로 예측 성능 평가. **탐색 시연:** 학습하지 않은 2014년 데이터로 예측오차와 유사 기록을 살펴봄.
- **유사 기록:** 2013년 입력 변수에 맞춘 표준화 후 최근접 이웃 1건. 자기 자신을 제외한 2013년 내부 최근접 거리의 95백분위수를 임시 문턱값으로 사용.
- **판단 보류:** 문턱을 넘으면 유사 기록의 배출량을 비교 근거로 사용하지 않음. 문턱값은 산업 표준이나 확률적 신뢰도가 아님.
- **출처와 라이선스:** [UCI 원본 데이터셋](https://archive.ics.uci.edu/dataset/551/gas+turbine+co+and+nox+emission+data+set), CC BY 4.0. 모델과 화면은 이 데이터를 바탕으로 제작.
"""
    )
    st.subheader("해석상 한계")
    st.info(
        "이 데이터에는 고장·법규 위반의 정답 라벨, 설비 정비 이력, 정확한 관측 시각이 없습니다. "
        "또한 다른 공정이나 현재 공장에 일반화됐다는 증거도 없습니다. "
        "예측오차나 과거 기록과의 차이는 조사 단서이며 원인을 증명하지 않습니다."
    )
    st.write("**첫 번째 후속 검증:** 보류 중인 2015년 데이터를 최종 평가로 사용하고, 연도별 편향이 반복되는지 확인합니다.")
    st.write("**서비스 범위:** UCI 데이터 기반의 오프라인 연구 시연이며 실시간 센서 연결, 자동 제어, 규제 준수 판정은 하지 않습니다.")
    st.write("**보안:** 공개 데이터와 번들로 제공한 모델만 사용합니다. 외부 파일 업로드나 사용자 데이터 저장 기능은 없습니다.")
